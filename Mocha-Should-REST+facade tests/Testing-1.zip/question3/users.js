module.exports = [
  {
    "email": "ultricies.adipiscing@utaliquam.ca",
    "password": "0B25A444-D4BC-8819-3632-D38626487588"
  },
  {
    "email": "parturient.montes.nascetur@euduiCum.ca",
    "password": "9A3752A5-89BF-0D3C-7D3A-69FEB0EC2651"
  },
  {
    "email": "quam@Loremipsum.com",
    "password": "3DBB2710-BB87-097B-3A1F-AF19AFDE5578"
  },
  {
    "email": "id.risus.quis@facilisis.net",
    "password": "A61077AA-8482-C0EA-FCBA-E8B1B14C7F64"
  },
  {
    "email": "dignissim.tempor@eratEtiam.net",
    "password": "79C77793-78C1-1377-4B90-EFAFC882B533"
  },
  {
    "email": "tellus.lorem@ipsum.com",
    "password": "52165F75-C20C-8F1E-3218-AC06800CA5AC"
  },
  {
    "email": "nec.euismod@adipiscingnon.co.uk",
    "password": "9C32C595-7A78-035C-288F-1749EE37F646"
  },
  {
    "email": "accumsan.sed.facilisis@purusgravida.com",
    "password": "46D28432-1B37-8B4A-D85B-0EC2E47EDA85"
  },
  {
    "email": "turpis@sem.co.uk",
    "password": "0D92E7A1-8740-F748-F24C-86496E6A53FF"
  }
];
